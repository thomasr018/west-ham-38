# West Ham 38-0

A simple West Ham-only football draft game.

## How to use

Open `index.html` in your browser.

## Files

- `index.html` - page structure
- `style.css` - design
- `script.js` - game logic and player database

## How to upload online

Upload the folder to Netlify, Vercel, GitHub Pages, or any static web host.

## Important

This is a fan-made starter project. Player ratings are custom/fun ratings, not official FIFA/EA ratings.
