const positions = [
  "GK", "RB", "CB", "CB", "LB",
  "CDM", "CM", "RW", "CAM", "LW", "ST"
];

const players = [
  { name: "Łukasz Fabiański", season: "2018/19", pos: "GK", rating: 86, pace: 40, shoot: 20, pass: 63, defend: 84, physical: 76 },
  { name: "Robert Green", season: "2006/07", pos: "GK", rating: 84, pace: 38, shoot: 18, pass: 58, defend: 83, physical: 78 },
  { name: "Alphonse Areola", season: "2023/24", pos: "GK", rating: 85, pace: 42, shoot: 18, pass: 61, defend: 85, physical: 80 },

  { name: "Pablo Zabaleta", season: "2017/18", pos: "RB", rating: 82, pace: 66, shoot: 58, pass: 75, defend: 82, physical: 78 },
  { name: "Vladimír Coufal", season: "2020/21", pos: "RB", rating: 83, pace: 74, shoot: 54, pass: 76, defend: 82, physical: 82 },
  { name: "Aaron Wan-Bissaka", season: "2024/25", pos: "RB", rating: 84, pace: 78, shoot: 52, pass: 70, defend: 88, physical: 80 },

  { name: "Winston Reid", season: "2015/16", pos: "CB", rating: 84, pace: 64, shoot: 42, pass: 62, defend: 86, physical: 85 },
  { name: "Angelo Ogbonna", season: "2020/21", pos: "CB", rating: 85, pace: 62, shoot: 39, pass: 65, defend: 87, physical: 84 },
  { name: "Kurt Zouma", season: "2021/22", pos: "CB", rating: 83, pace: 58, shoot: 45, pass: 62, defend: 84, physical: 88 },
  { name: "James Collins", season: "2012/13", pos: "CB", rating: 82, pace: 49, shoot: 38, pass: 55, defend: 84, physical: 86 },

  { name: "Aaron Cresswell", season: "2015/16", pos: "LB", rating: 84, pace: 74, shoot: 67, pass: 82, defend: 80, physical: 75 },
  { name: "Emerson", season: "2023/24", pos: "LB", rating: 84, pace: 78, shoot: 61, pass: 80, defend: 81, physical: 76 },

  { name: "Declan Rice", season: "2022/23", pos: "CDM", rating: 91, pace: 78, shoot: 74, pass: 86, defend: 90, physical: 91 },
  { name: "Tomáš Souček", season: "2020/21", pos: "CDM", rating: 85, pace: 63, shoot: 78, pass: 73, defend: 83, physical: 90 },
  { name: "Alex Song", season: "2014/15", pos: "CDM", rating: 84, pace: 66, shoot: 65, pass: 84, defend: 82, physical: 83 },

  { name: "Mark Noble", season: "2015/16", pos: "CM", rating: 84, pace: 58, shoot: 73, pass: 85, defend: 76, physical: 78 },
  { name: "Lucas Paquetá", season: "2023/24", pos: "CM", rating: 88, pace: 76, shoot: 80, pass: 88, defend: 76, physical: 82 },
  { name: "Scott Parker", season: "2010/11", pos: "CM", rating: 87, pace: 70, shoot: 75, pass: 84, defend: 86, physical: 87 },

  { name: "Jarrod Bowen", season: "2021/22", pos: "RW", rating: 88, pace: 84, shoot: 87, pass: 80, defend: 62, physical: 78 },
  { name: "Michail Antonio", season: "2016/17", pos: "RW", rating: 84, pace: 86, shoot: 80, pass: 74, defend: 66, physical: 91 },
  { name: "Mohammed Kudus", season: "2023/24", pos: "RW", rating: 88, pace: 87, shoot: 84, pass: 82, defend: 61, physical: 84 },

  { name: "Dimitri Payet", season: "2015/16", pos: "CAM", rating: 92, pace: 78, shoot: 88, pass: 94, defend: 48, physical: 74 },
  { name: "Joe Cole", season: "2002/03", pos: "CAM", rating: 86, pace: 82, shoot: 80, pass: 87, defend: 55, physical: 70 },
  { name: "Manuel Lanzini", season: "2016/17", pos: "CAM", rating: 85, pace: 79, shoot: 80, pass: 86, defend: 51, physical: 68 },

  { name: "Said Benrahma", season: "2021/22", pos: "LW", rating: 83, pace: 81, shoot: 78, pass: 81, defend: 44, physical: 68 },
  { name: "Felipe Anderson", season: "2018/19", pos: "LW", rating: 86, pace: 88, shoot: 82, pass: 84, defend: 49, physical: 70 },
  { name: "Matthew Etherington", season: "2005/06", pos: "LW", rating: 82, pace: 84, shoot: 74, pass: 80, defend: 52, physical: 71 },

  { name: "Paolo Di Canio", season: "1999/00", pos: "ST", rating: 90, pace: 76, shoot: 91, pass: 85, defend: 40, physical: 76 },
  { name: "Carlos Tevez", season: "2006/07", pos: "ST", rating: 89, pace: 84, shoot: 88, pass: 83, defend: 55, physical: 86 },
  { name: "Andy Carroll", season: "2012/13", pos: "ST", rating: 83, pace: 58, shoot: 82, pass: 68, defend: 60, physical: 94 },
  { name: "Teddy Sheringham", season: "2004/05", pos: "ST", rating: 84, pace: 45, shoot: 86, pass: 86, defend: 42, physical: 70 }
];

let currentPick = 0;
let squad = [];
let currentOptions = [];

const startBtn = document.getElementById("startBtn");
const rerollBtn = document.getElementById("rerollBtn");
const simulateBtn = document.getElementById("simulateBtn");
const resetBtn = document.getElementById("resetBtn");
const optionsBox = document.getElementById("options");
const squadList = document.getElementById("squadList");
const pickTitle = document.getElementById("pickTitle");
const result = document.getElementById("result");

function randomItems(arr, amount) {
  const shuffled = [...arr].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, amount);
}

function getOptions() {
  const pos = positions[currentPick];
  const chosenNames = squad.map(p => p.name);
  const pool = players.filter(p => p.pos === pos && !chosenNames.includes(p.name));
  currentOptions = randomItems(pool, Math.min(3, pool.length));
  renderOptions();
}

function renderOptions() {
  optionsBox.innerHTML = "";

  currentOptions.forEach(player => {
    const card = document.createElement("div");
    card.className = "player-card";

    card.innerHTML = `
      <div>
        <div class="rating">${player.rating}</div>
        <h3>${player.name}</h3>
        <p class="meta">${player.season} • ${player.pos}</p>
        <div class="stats">
          <div class="stat">PAC ${player.pace}</div>
          <div class="stat">SHO ${player.shoot}</div>
          <div class="stat">PAS ${player.pass}</div>
          <div class="stat">DEF ${player.defend}</div>
          <div class="stat">PHY ${player.physical}</div>
          <div class="stat">OVR ${player.rating}</div>
        </div>
      </div>
      <button>draft player</button>
    `;

    card.querySelector("button").addEventListener("click", () => choosePlayer(player));
    optionsBox.appendChild(card);
  });
}

function choosePlayer(player) {
  squad.push(player);
  currentPick++;
  renderSquad();
  result.classList.add("hidden");

  if (currentPick >= positions.length) {
    pickTitle.textContent = "XI complete";
    optionsBox.innerHTML = "";
    rerollBtn.disabled = true;
    simulateBtn.disabled = false;
    return;
  }

  pickTitle.textContent = `${positions[currentPick]} needed`;
  getOptions();
}

function renderSquad() {
  squadList.innerHTML = "";

  squad.forEach((player, index) => {
    const item = document.createElement("div");
    item.className = "squad-item";
    item.textContent = `${positions[index]}: ${player.name} ${player.rating}`;
    squadList.appendChild(item);
  });
}

function simulateSeason() {
  const average = squad.reduce((sum, p) => sum + p.rating, 0) / squad.length;
  const attack = squad.filter(p => ["RW", "CAM", "LW", "ST"].includes(p.pos)).reduce((s, p) => s + p.rating, 0) / 4;
  const defence = squad.filter(p => ["GK", "RB", "CB", "LB", "CDM"].includes(p.pos)).reduce((s, p) => s + p.rating, 0) / 6;
  const luck = Math.floor(Math.random() * 9) - 3;

  let wins = Math.round((average - 67) + luck);
  wins = Math.max(18, Math.min(38, wins));

  let draws = Math.max(0, Math.round((92 - average) / 2));
  let losses = Math.max(0, 38 - wins - draws);

  if (wins + draws + losses > 38) {
    losses = 38 - wins - draws;
  }

  if (wins === 38) {
    draws = 0;
    losses = 0;
  }

  const points = wins * 3 + draws;
  const goalsFor = Math.round(attack * 1.45 + wins * 1.7);
  const goalsAgainst = Math.max(12, Math.round(95 - defence + losses * 4));

  let verdict = "solid season but not quite immortals";
  if (wins >= 34) verdict = "ridiculous moyes statue outside the ground stuff";
  if (wins === 38) verdict = "38-0. greatest west ham side ever. parade down green street.";

  result.innerHTML = `
    <strong>${wins}W ${draws}D ${losses}L</strong><br>
    ${points} points • ${goalsFor} scored • ${goalsAgainst} conceded<br>
    Team rating: ${average.toFixed(1)}<br>
    <em>${verdict}</em>
  `;
  result.classList.remove("hidden");
}

function resetGame() {
  currentPick = 0;
  squad = [];
  currentOptions = [];
  optionsBox.innerHTML = "";
  squadList.innerHTML = "";
  pickTitle.textContent = "press start";
  result.classList.add("hidden");
  rerollBtn.disabled = true;
  simulateBtn.disabled = true;
}

startBtn.addEventListener("click", () => {
  resetGame();
  pickTitle.textContent = `${positions[currentPick]} needed`;
  rerollBtn.disabled = false;
  getOptions();
});

rerollBtn.addEventListener("click", getOptions);
simulateBtn.addEventListener("click", simulateSeason);
resetBtn.addEventListener("click", resetGame);
